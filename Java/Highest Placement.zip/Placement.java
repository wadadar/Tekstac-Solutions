import java.util.Scanner;
class Placement {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the no of students placed in CSE:");
        int cse=sc.nextInt();
        System.out.print("Enter the no of students placed in ECE:");
        int ece=sc.nextInt();
        System.out.print("Enter the no of students placed in MECH:");
        int mech=sc.nextInt();
        if(cse<0 || ece<0 || mech<0)
            System.out.println("Input is Invalid");
        else if((cse==0 && ece==0 && mech==0)||cse==mech && mech==ece)
            System.out.println("None of the department has got the highest placement");
        else
        {
            int high=(cse>ece)?((cse>mech)?cse:mech):((ece>mech)?ece:mech);
            System.out.println("Highest placement");
            if(cse==high)
                System.out.println("CSE");
            if(ece==high)
                System.out.println("ECE");
            if(mech==high)
                System.out.println("MECH");
            
        }
        
    }
}