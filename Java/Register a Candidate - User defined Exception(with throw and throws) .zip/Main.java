import java.util.Scanner;
public class Main{
    public static Candidate getCandidateDetails() throws InvalidSalaryException
    {
        Scanner sc=new Scanner(System.in);
        Candidate c=new Candidate();
        System.out.println("Enter the candidate Details\nName");
        c.setName(sc.next());
        System.out.println("Gender");
        c.setGender(sc.next());
        System.out.println("Expected salary");
        double sal=sc.nextDouble();
        if(sal>=10000)
            c.setExpectedSalary(sal);
        else    
            throw new InvalidSalaryException("Registration failed. Salary cannot be less than 10000.");
        return c;
    }
    public static void main(String args[])
    {
        Candidate c=null;
        try{
            c=getCandidateDetails();
            System.out.println("Registration successful");
        }
        catch(InvalidSalaryException e)
        {
            System.out.println(e.getMessage());
        }
    }
}