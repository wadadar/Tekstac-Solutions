public interface Insurance
{
    public double takeInsurance();
}