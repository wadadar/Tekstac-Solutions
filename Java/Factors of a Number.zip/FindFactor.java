import java.util.Scanner;
class FindFactor{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        n=(n<0)?-n:n;
        if(n==0)
            System.out.println("No Factors");
        else
        {
            for(int i=1;i<n;i++)
            {
                if(n%i==0)
                    System.out.print(i+", ");
            }
            System.out.print(n);
        }
    }
}