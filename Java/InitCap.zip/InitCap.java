import java.util.*;
public class InitCap
{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String:");
        String words[]=sc.nextLine().split(" ");
        String newStr="";
        int allcap=1;
        for(String w:words)
        {
            if(Character.isLowerCase(w.charAt(0))) 
                allcap=0;
            newStr+=Character.toUpperCase(w.charAt(0))+w.substring(1)+" ";
        }
        if(allcap==1)
            System.out.println("First character of each word is already in uppercase");
        else
            System.out.println(newStr);
    }
}