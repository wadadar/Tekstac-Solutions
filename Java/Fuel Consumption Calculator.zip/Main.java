import java.util.Scanner;
class Main{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the no of liters to fill the tank");
        int fuel=sc.nextInt();
        if(fuel<=0)
        {
            System.out.println(fuel+" is an Invalid Input");
        }
        else{
            System.out.println("Enter the distance covered");
            int d=sc.nextInt();
            if(d<=0)
            {
                System.out.println(d+" is an Invalid Input");
            }
            else
            {
                System.out.printf("Liters/100KM\n%.2f",(fuel*100.0f)/d);
                System.out.printf("\nMiles/gallons\n%.2f",(d*0.6214f)/(fuel*0.2642f));
            }
        }
        
    }
}