import java.util.Scanner;
class PanCard{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the PAN no:");
        String pan=sc.next();
        int flag=0;
        if(pan.length()==10)
        {
            for(int i=0;i<5;i++)
            {
                if(pan.charAt(i)<65 || pan.charAt(i)>90)
                {
                    flag=1;
                    break;
                }
            }
            if(flag!=1)
            {
                for(int i=5;i<8;i++)
                {
                    if(pan.charAt(i)<48||pan.charAt(i)>57)
                    {
                        flag=1;
                        break;
                    }
                }
                if(flag!=1 && Character.isUpperCase(pan.charAt(9)))
                    System.out.println("Valid PAN no");
            }
        }
        else
        {
            flag=1;
        }
        if(flag==1)
            System.out.println("Invalid PAN no");
    }
}