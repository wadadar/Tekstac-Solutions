import java.sql.*;
public class FlightManagementSystem
{
    public boolean addFlight(Flight obj)
    {
        try{
            DB db=new DB();
            Connection con=db.getConnection();
            PreparedStatement st=con.prepareStatement("insert into flight values(?,?,?,?,?)");
            st.setInt(1,obj.getFlightId());
            st.setString(2,obj.getSource());
            st.setString(3,obj.getDestination());
            st.setInt(4,obj.getNoOfSeats());
            st.setDouble(5,obj.getFlightFare());
            int c=st.executeUpdate();
            if(c==1)
                return true;
            return false;
        }
        catch(Exception e)
        {
            return false;
        }
    }
}