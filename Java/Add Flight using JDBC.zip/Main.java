import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        FlightManagementSystem fs=new FlightManagementSystem();
        Flight f=new Flight(123,"Dehradun","Mysore",2,5000);
        if(fs.addFlight(f))
            System.out.println("Flight details added successfully");
        else
            System.out.println("Addition not done");
    }
}