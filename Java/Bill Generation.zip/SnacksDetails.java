import java.util.Scanner;
class SnacksDetails{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the no of pizzas bought:");
        int pz=sc.nextInt();
        System.out.print("Enter the no of puffs bought:");
        int pf=sc.nextInt();
        System.out.print("Enter the no of cool drinks bought:");
        int cd=sc.nextInt();
        
        System.out.println("Bill Details");
        System.out.println("No of pizzas:"+pz+"\nNo of puffs:"+pf+"\nNo of cooldrinks:"+cd);
        int total=(pz*100)+(pf*20)+(cd*10);
        System.out.println("Total price="+total+"\nENJOY THE SHOW!!!");
    }
}