import java.util.Scanner;
class Season{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the month:");
        int n=sc.nextInt();
        if(n<1 || n>12)
            System.out.println("Invalid month");
        else if(n>=2 && n<=5)
            System.out.print("Season:Spring");
        else if(n>=6 && n<=8)
            System.out.print("Season:Summer");
        else if(n>=9 && n<=11)
            System.out.print("Season:Autumn");
        else
            System.out.print("Season:Winter");
        
    }
}