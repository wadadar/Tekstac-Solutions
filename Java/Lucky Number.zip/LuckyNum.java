import java.util.Scanner;
class LuckyNum{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the car no:");
        int n=sc.nextInt();
        if(n<1000 || n>9999)
            System.out.println(n+" is not a valid car number");
        else{
            int sum=0,num=n;
            while(num>0)
            {
                int r=num%10;
                sum+=r;
                num/=10;
            }
            if(sum%3==0 || sum%5==0 || sum%7==0)
                System.out.println("Lucky Number");
            else
                System.out.println("Sorry its not my lucky number");
        }
    }
}