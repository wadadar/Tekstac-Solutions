public class Cube extends Shape implements Spatial
{
    private double length;
    private double width;
    private double height;
    public void setLength(double length){this.length=length;}
    public double getLength(){return this.length;}
    public void setWidth(double width){this.width=width;}
    public double getWidth(){return this.width;}
    public void setHeight(double height){this.height=height;}
    public double getHeight(){return this.height;}
    public double area()
    {return 2*(length*width+length*height+width*height);}
    public double volume()
    {return length*width*height;}
}