import java.util.Scanner;
public class Main
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Shape shapeArr[]=new Shape[5];
        for(int i=0;i<5;i++)
        {
            String shape=sc.next();
            if(shape.equalsIgnoreCase("cube"))
            {
                Cube obj=new Cube();
                obj.setLength(sc.nextDouble());
                obj.setWidth(sc.nextDouble());
                obj.setHeight(sc.nextDouble());
                shapeArr[i]=obj;
                
            }
            else if(shape.equalsIgnoreCase("rectangle"))
            {
                Rectangle obj=new Rectangle();
                obj.setLength(sc.nextDouble());
                obj.setWidth(sc.nextDouble());
                shapeArr[i]=obj;
            }
            else if(shape.equalsIgnoreCase("sphere"))
            {
                Sphere obj=new Sphere();
                obj.setRadius(sc.nextDouble());
                shapeArr[i]=obj;
            }
            else if(shape.equalsIgnoreCase("triangle"))
            {
                Triangle obj=new Triangle();
                obj.setBase(sc.nextDouble());
                obj.setHeight(sc.nextDouble());
                shapeArr[i]=obj;
            }
            else
            {
                System.out.println("Invalid Input");
            }
        }
        for(int i=0;i<5;i++)
        {
            System.out.printf("Area "+shapeArr[i].area()+"\n");
            if(shapeArr[i] instanceof Spatial)
                System.out.println("Volume "+shapeArr[i].volume());
            
        }
    }
}