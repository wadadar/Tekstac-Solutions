public class Rectangle extends Shape
{
    private double length;
    private double width;
    public void setLength(double length)
    {
        this.length=length;
    }
    public double getLength()
    {
        return this.length;
    }
    public void setWidth(double width)
    {
        this.width=width;
    }
    public double getWidth()
    {
        return this.width;
    }
    public double volume()
    {
        return -1;
    }
    public double area()
    {
        return this.length*this.width;
    }
}