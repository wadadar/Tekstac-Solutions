import java.util.*;
public class Main
{
    public static Employee getEmployeeDetails()
    {
        Scanner sc = new Scanner(System.in);
        Employee obj = new Employee();
        System.out.println("Enter Id:");
        obj.setEmployeeId(sc.nextInt());
        System.out.println("Enter name:");
        obj.setEmployeeName(sc.next());
        System.out.println("Enter salary:");
        obj.setSalary(sc.nextDouble());
        return obj;
    }
    public static int getPFPercentage()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter PF percentage:");
        int pf=sc.nextInt();
        return pf;
    }
    public static void main (String[] args) {
        Employee empObj = null;
        empObj=getEmployeeDetails();
        int pf1=getPFPercentage();
        empObj.calculateNetSalary(pf1);
        System.out.println("Id : "+empObj.getEmployeeId());
        System.out.println("Name : "+empObj.getEmployeeName());
        System.out.printf("Salary : %.1f\n",empObj.getSalary());
        System.out.printf("Net Salary : %.1f",empObj.getNetSalary());
        
    }
    
}