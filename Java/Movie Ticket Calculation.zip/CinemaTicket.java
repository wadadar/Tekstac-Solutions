import java.util.Scanner;
class CinemaTicket{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the no of ticket:");
        int n=sc.nextInt();
        if(n<5||n>40)
            System.out.println("Minimum of 5 and Maximum of 40 Tickets");
        else
        {
            System.out.print("Do you want refreshment:");
            char r=sc.next().charAt(0);
            System.out.print("Do you have coupon code:");
            char cc=sc.next().charAt(0);
            System.out.print("Enter the circle:");
            char cl=sc.next().charAt(0);
            if(!(cl=='k'||cl=='q'))
                System.out.println("Invalid Input");
            else
            {
                float cost;
                if(cl=='k')
                    cost=n*75;
                else
                    cost=n*150;
                if(n>20)
                    cost=cost-(cost*0.1f);
                if(cc=='y')
                    cost=cost-(cost*0.02f);
                if(r=='y')
                    cost+=n*50;
                System.out.printf("Ticket cost:%.2f",cost);
            }
        }
        
    }
}