import java.util.Scanner;
public class TestApplication {
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    AddressBook ab=new AddressBook();
	    AddressBook.Address padd,tadd;
	    padd=ab.new Address();
	    tadd=ab.new Address();
	    System.out.println("Enter the permanent address\nEnter the house name");
	    padd.setName(sc.nextLine());
	    System.out.println("Enter the street");
	    padd.setStreet(sc.nextLine());
	    System.out.println("Enter the city");
	    padd.setCity(sc.nextLine());
	    System.out.println("Enter the state");
	    padd.setState(sc.nextLine());
	    ab.setPermAddress(padd);
	    
	    System.out.println("Enter the temporary address\nEnter the house name");
	    tadd.setName(sc.nextLine());
	    System.out.println("Enter the street");
	    tadd.setStreet(sc.nextLine());
	    System.out.println("Enter the city");
	    tadd.setCity(sc.nextLine());
	    System.out.println("Enter the state");
	    tadd.setState(sc.nextLine());
	    ab.setTempAddress(tadd);
	    
	    System.out.println("Enter the phone number");
	    ab.setPhoneNumber(sc.nextLong());
	    
	    System.out.println("Permanent address");
	    System.out.println("House name:"+ab.getPermAddress().getName());
	    System.out.println("Street:"+ab.getPermAddress().getStreet());
	    System.out.println("City:"+ab.getPermAddress().getCity());
	    System.out.println("State:"+ab.getPermAddress().getState());
	    System.out.println("Temporary address");
	    System.out.println("House name:"+ab.getTempAddress().getName());
	    System.out.println("Street:"+ab.getTempAddress().getStreet());
	    System.out.println("City:"+ab.getTempAddress().getCity());
	    System.out.println("State:"+ab.getTempAddress().getState());
	    System.out.println("Phone number\n"+ab.getPhoneNumber());
	}
}