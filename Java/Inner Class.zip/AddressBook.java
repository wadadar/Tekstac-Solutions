public class AddressBook{
    
    public class Address{
        private String name;
        private String street;
        private String city;
        private String state;
        public void setName(String name){this.name=name;}
        public String getName(){return this.name;}
        public void setStreet(String street){this.street=street;}
        public String getStreet(){return this.street;}
        public void setCity(String city){this.city=city;}
        public String getCity(){return this.city;}
        public void setState(String state){this.state=state;}
        public String getState(){return this.state;}
    }
    
    private long phoneNumber;
    private Address tempAddress;
    private Address permAddress;
    
    public void setTempAddress(Address tempAddress){this.tempAddress=tempAddress;}
    public Address getTempAddress(){return this.tempAddress;}
    public void setPermAddress(Address permAddress){this.permAddress=permAddress;}
    public Address getPermAddress(){return this.permAddress;}
    public void setPhoneNumber(long phoneNumber){this.phoneNumber=phoneNumber;}
    public long getPhoneNumber(){return this.phoneNumber;}
}