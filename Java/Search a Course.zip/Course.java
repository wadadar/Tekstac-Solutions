import java.util.Scanner;
class Course{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter no of course:");
        int n=sc.nextInt();
        if(n<=0 || n>20)
        {
            System.out.println("Invalid Range");
            System.exit(0);
        }
        String course[]=new String[n];
        System.out.println("Enter course names:");
        for(int i=0;i<n;i++)
        {
            course[i]=sc.next();
        }
        System.out.println("Enter the course to be searched:");
        String key=sc.next();
        for(int i=0;i<n;i++)
        {
            if(key.equals(course[i]))
            {
                System.out.println(key+" course is available");
                System.exit(0);
            }
        }
        System.out.println(key+" course is not available");
    }
}