import java.util.*;
public class Main{
    
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Customer id");
        int customerId=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the Customer Name");
        String name=sc.nextLine();
        System.out.println("Enter the Email id");
        String emailid=sc.nextLine(); 
        Customer c = new Customer(customerId,name,emailid);
        System.out.println("Enter the Account number");
        int accountNumber=sc.nextInt();
        System.out.println("Enter the Balance");
        double balance=sc.nextDouble();
        //Account a = new Account(accountNumber,c,balance);
        System.out.println("Enter the minimum balance");
        double minimumBalance=sc.nextDouble();
        SavingsAccount sa= new SavingsAccount(accountNumber,c,balance,minimumBalance);
        System.out.println("Enter the amount to withdraw");
        double amount=sc.nextDouble();
        sa.withdraw(amount);
        c.getCustomerId();
        c.getCustomerName();
        c.getEmailId();
        sa.getAccountNumber();
        sa.getCustomerObj();
        sa.getBalance();
        sa.getMinimumBalance();
    }
}