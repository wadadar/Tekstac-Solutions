import java.util.*;
import java.time.LocalDateTime;
import java.time.format.*;
import java.time.temporal.ChronoUnit;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("In-time");
        String inTime=sc.nextLine();
        DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime now=LocalDateTime.parse("29/10/2019 20:10",formatter);
        try{
            LocalDateTime in=LocalDateTime.parse(inTime,formatter);
            long diff1=ChronoUnit.MINUTES.between(in,now);
            if(diff1>=1){
                System.out.println("Out-Time");
                String outTime=sc.nextLine();
                try{
                    LocalDateTime out=LocalDateTime.parse(outTime,formatter);
                    long diff2=ChronoUnit.MINUTES.between(in,out);
                    if(diff2>=1){
                        int hr;
                        if(diff2%60==0){
                            hr=(int)diff2/60;
                        }
                        else{
                            hr=1+(int)diff2/60;
                        }
                        System.out.println(hr*10+" Rupees");
                    }
                    else{
                        System.out.println(outTime+" is an Invalid Out-Time");
                    }
                }
                catch(DateTimeParseException e){
                    System.out.println(outTime+" is an Invalid Out-Time");
                }
            }
            else{
                System.out.println(inTime+" is an Invalid In-Time");
            }
        }
        catch(DateTimeParseException e){
            System.out.println(inTime+" is an Invalid In-Time");
        }
        sc.close();
    }
}