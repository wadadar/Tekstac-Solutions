package com.ui;
import com.utility.*;
import java.util.*;
import java.util.Map.Entry;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the no of Policy names you want to store");
        int n=sc.nextInt();
        Bazaar b=new Bazaar();
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter the Policy ID");
            int pid=sc.nextInt();
            sc.nextLine();
            System.out.println("Enter the Policy Name");
            String name=sc.nextLine();
            b.addPolicyDetails(pid,name);
        }
        Set<Entry<Integer,String>> eset=b.getPolicyMap().entrySet();
        for(Entry<Integer,String> e:eset)
        {
            System.out.println(e.getKey()+" "+e.getValue());
        }
        System.out.println("Enter the policy type to be searched");
        String key=sc.next();
        List<Integer> policies=b.searchBasedOnPolicyType(key);
        for(Integer p:policies)
        {
            System.out.println(p);
        }
	}

}
