//Make this class inherit the Employee class

public class PermanentEmployee extends Employee 
{
    private double basicPay;

    public double getBasicPay() {
		return basicPay;
	}

	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}
    
    public PermanentEmployee(int employeeId,String employeeName,double basicPay)
    {
        super(employeeId,employeeName);
        this.basicPay=basicPay;
        
    }
     public void calculateSalary()
     {
         this.setSalary(this.basicPay-(this.basicPay*0.12));
     }
    
    
    
}