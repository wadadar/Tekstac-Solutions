import java.util.Scanner;
class PrimeNumbers{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        if(a<=0||b<=0||(a>b)||(b-a)<=0)
            System.out.println("Provide valid input");
        else
        {
            for(int i=a;i<=b;i++)
            {
                int j=1,count=0;
                while(j<=i/2)
                {
                    if(i%j==0)
                       count++;
                    j++;
                }
                if(count==1)
                    System.out.print(i+" ");
            }
        }
    }
}