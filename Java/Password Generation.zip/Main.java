import java.util.*;
public class Main{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Generate your Security Code");
        String code=sc.next();
        String pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#*])(?=\\S+$).{8,}$";
        if(code.matches(pattern))
        System.out.println("Security Code Generated Successfully");
        else
        System.out.println("Invalid Security Code, Try Again!");
    }
}