import java.util.Scanner;
class HighestMarkPerSem{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter no of semester:");
        int n=sc.nextInt();
        int[] sem=new int[n];
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter no of subjects in "+(i+1)+" semester");
            sem[i]=sc.nextInt();
        }
        int[][] Marks=new int[n][];
        for(int i=0;i<n;i++)
        {
            Marks[i]=new int[sem[i]];
            System.out.println("Marks obtained in semester "+(i+1)+":");
            for(int j=0;j<sem[i];j++)
            {
                Marks[i][j]=sc.nextInt();
                if(!(Marks[i][j]>=0 && Marks[i][j]<=100))
                {
                    System.out.println("You have entered invalid mark.");
                    System.exit(0);
                }
            }
        }
        for(int i=0;i<n;i++)
        {
            int max=Marks[i][0];
            for(int j=0;j<Marks[i].length;j++)
            {
                if(max<Marks[i][j])
                    max=Marks[i][j];
            }
            System.out.println("Maximum mark in "+(i+1)+" semester:"+max);
        }
        
    }
}