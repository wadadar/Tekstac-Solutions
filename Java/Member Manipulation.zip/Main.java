import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        Library l=new Library();
        while(true)
        {
            System.out.println("1.Add Member\n2.View All Members\n3.Search Member by address\n4.Exit");
            int ch=sc.nextInt();
            if(ch==1)
            {
                Member m=new Member();
                System.out.println("Enter your id:");
                m.setMemberId(sc.nextInt());
                sc.nextLine();
                System.out.println("Enter the name:");
                m.setMemberName(sc.nextLine());
                System.out.println("Enter the address");
                m.setAddress(sc.nextLine());
                l.addMember(m); 
            }
            else if(ch==2)
            {
                if(l.getMemberList().isEmpty())
                    System.out.println("The list is empty");
                for(Member m:l.getMemberList())
                {
                    System.out.println("Id:"+m.getMemberId()+"\nName:"+m.getMemberName()+"\nAddress:"+m.getAddress());
                }
            }
            else if(ch==3)
            {
                sc.nextLine();
                System.out.println("Enter the address");
                List<Member> list=l.viewMembersByAddress(sc.nextLine());
                if(list.isEmpty())
                    System.out.println("None of the member is from chennai");
                for(Member m:list)
                {
                    System.out.println("Id:"+m.getMemberId()+"\nName:"+m.getMemberName()+"\nAddress:"+m.getAddress());
                }
            }
            else if(ch==4)   
                break;
            else    
                System.out.println("Wrong choice");
        }
    }
}