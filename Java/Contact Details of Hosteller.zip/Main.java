import java.util.*;
public class Main
{
    static Hosteller host;
    public static Hosteller getHostellerDetails()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Modify Room Number(Y/N)");
        String ch=sc.nextLine();
        if(ch.equalsIgnoreCase("Y"))
        {
            System.out.println("New Room Number");
            host.setRoomNumber(sc.nextInt());
            sc.nextLine();
        }
        System.out.println("Modify Phone Number(Y/N)");
        ch=sc.nextLine();
        if(ch.equalsIgnoreCase("Y"))
        {
            System.out.println("New Phone Number");
            host.setPhone(sc.nextLine());
        }
        return host;
        
    }
    public static void main (String[] args) {
        
        Scanner sc = new Scanner (System.in);
        Student stu=new Student();
        host=new Hosteller();
        System.out.println("Enter the Details:");
        System.out.println("Student Id");
        int studentId=sc.nextInt();
        sc.nextLine();
        host.setStudentId(studentId);
        System.out.println("Student Name");
        String name=sc.nextLine();
        host.setName(name);
        System.out.println("Department Id");
        int departmentId=sc.nextInt();
        sc.nextLine();
        host.setDepartmentId(departmentId);
        System.out.println("Gender");
        String gender=sc.nextLine();
        host.setGender(gender);
        System.out.println("Phone Number");
        String phno=sc.nextLine();
        host.setPhone(phno);
        System.out.println("Hostel Name");
        host.setHostelName(sc.nextLine());
        System.out.println("Room Number");
        host.setRoomNumber(sc.nextInt());
        sc.nextLine();
        getHostellerDetails();
        System.out.println("The Student Details:");
        System.out.println(host.getStudentId()+" "+host.getName()+" "+host.getDepartmentId()+" "+host.getGender()+" "+host.getPhone()+" "+host.getHostelName()+" "+host.getRoomNumber());
    }
}