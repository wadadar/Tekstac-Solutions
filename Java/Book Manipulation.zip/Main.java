import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
 public class Main{
     public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        Library l=new Library();
        while(true)
        {
            System.out.println("1.Add Book\n2.Display all book details\n3.Search Book by author\n4.Count number of books - by book name\n5.Exit");
            int ch=sc.nextInt();
            if(ch==1)
            {
                Book b=new Book();
                System.out.println("Enter the isbn no:");
                b.setIsbnno(sc.nextInt());
                sc.nextLine();
                System.out.println("Enter the book name:");
                b.setBookName(sc.nextLine());
                System.out.println("Enter the author name:");
                b.setAuthor(sc.nextLine());
                l.addBook(b);
            }
            if(ch==2)
            {
                for(Book b: l.getBookList())
                {
                    System.out.println(b.getIsbnno()+" "+b.getBookName()+" "+b.getAuthor());
                }
            }
            if(ch==3)
            {
                sc.nextLine();
                System.out.println("Enter the author name:");
                ArrayList<Book> list=l.viewBooksByAuthor(sc.nextLine());
                if(list.isEmpty())
                    System.out.println("This list is Empty");
                for(Book b:list)
                {
                    System.out.println("ISBN no: "+b.getIsbnno()+"\nBook name: "+b.getBookName()+"\nAuthor name: "+b.getAuthor());
                }
            }
            if(ch==4)
            {
                System.out.println("Enter the book name:");
                System.out.println("Count of books: "+l.countnoofbook(sc.nextLine()));
            }
            if(ch==5)
            {
                break;
            }
        }
    }
 }
