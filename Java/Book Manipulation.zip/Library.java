import java.util.ArrayList;
import java.util.Collections;
public class Library{
    private ArrayList<Book> bookList;
    public Library()
    {
        this.bookList=new ArrayList<Book>();   
    }
    public void setBookList(ArrayList<Book> bookList)
    {
        this.bookList.addAll(bookList);
    }
    public ArrayList<Book> getBookList(){
        return this.bookList;
    }
    public void addBook(Book bobj)
    {
        this.bookList.add(bobj);
    }
    public boolean isEmpty()
    {
        return this.bookList.isEmpty();
    }
    public ArrayList<Book> viewAllBooks()
    {
        return this.bookList;
    }
    public ArrayList<Book> viewBooksByAuthor(String author)
    {
        ArrayList<Book> search=new ArrayList<Book>();
        for(Book b:this.bookList)
        {
            if(b.getAuthor().equals(author))
                search.add(b);
        }
        return search;
    }
    public int countnoofbook(String name)
    {
        int count=0;
        for(Book b:this.bookList)
            if(b.getBookName().equals(name))
                count++;
        return count;
    }
}