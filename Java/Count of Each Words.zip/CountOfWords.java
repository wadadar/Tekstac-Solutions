import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Collections;

@SuppressWarnings("unchecked")//Do not delete this line
public class CountOfWords
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        str=str.replaceAll("[,;:.?!]"," ");
        str=str.replaceAll("[ ]{2,}"," ");
        str=str.toLowerCase();
        String arr[]=str.split(" ");
        Map<String,Integer> map=new TreeMap<String,Integer>();
        int count=0;
        for(String w:arr){
            count++;
            Integer n=map.get(w);
            n=(n==null)?1:++n;
            map.put(w,n);
        }
        System.out.println("Number of words "+count);
        System.out.print("Words with the count");
        Set<Entry<String,Integer>> eset=map.entrySet();
        for(Entry<String,Integer> e:eset){
            System.out.print("\n"+e.getKey()+": "+e.getValue());
        }
    }
}