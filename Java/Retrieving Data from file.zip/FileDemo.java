import java.io.File;
import java.util.Scanner;
import java.io.*;

@SuppressWarnings("unchecked")
public class FileDemo
{
    public static void main(String[] args)
    {
        try{
        File file=new File("log.txt");
        Scanner sc=new Scanner(file);
        while(sc.hasNextLine())
            System.out.println(sc.nextLine());
        }
        catch(IOException e){
            System.out.println("Some error occured");
            e.printStackTrace();
        }
    }
}